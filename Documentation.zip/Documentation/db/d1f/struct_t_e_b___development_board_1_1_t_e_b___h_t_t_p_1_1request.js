var struct_t_e_b___development_board_1_1_t_e_b___h_t_t_p_1_1request =
[
    [ "connectionTimeout", "db/d1f/struct_t_e_b___development_board_1_1_t_e_b___h_t_t_p_1_1request.html#a4ed2f382d79666b1b106aff7473f3c78", null ],
    [ "requestText", "db/d1f/struct_t_e_b___development_board_1_1_t_e_b___h_t_t_p_1_1request.html#a7c47512421338494b22e918d5235eb70", null ],
    [ "responseDelay", "db/d1f/struct_t_e_b___development_board_1_1_t_e_b___h_t_t_p_1_1request.html#ac85ca0f95885b565017b6b6c8ba8dfe2", null ],
    [ "rootCA", "db/d1f/struct_t_e_b___development_board_1_1_t_e_b___h_t_t_p_1_1request.html#a98479e2569aff2c4f91202878bfb7125", null ],
    [ "serverAddress", "db/d1f/struct_t_e_b___development_board_1_1_t_e_b___h_t_t_p_1_1request.html#a51c59fd09c621aa56668b62e1a452b3b", null ],
    [ "serverPort", "db/d1f/struct_t_e_b___development_board_1_1_t_e_b___h_t_t_p_1_1request.html#a3296902533411579f0ffe82c4bb9d69b", null ]
];