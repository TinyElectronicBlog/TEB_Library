var searchData=
[
  ['updatefilecontent_201',['updateFileContent',['../de/d6f/class_t_e_b___drive.html#a7b7278e24bc9b887fec0cdff7dc1dbc2',1,'TEB_Drive']]],
  ['updatefilemetadata_202',['updateFileMetadata',['../de/d6f/class_t_e_b___drive.html#aae7d488ddaf4e988e82228230ea0c3e8',1,'TEB_Drive']]],
  ['usedynamicbuffer_203',['useDynamicBuffer',['../de/d6f/class_t_e_b___drive.html#a9931f0057c46004999059df0fc1df87e',1,'TEB_Drive::useDynamicBuffer()'],['../d9/dca/class_t_e_b___o_auth2.html#aef2c2642487891379404644bdce97cd0',1,'TEB_OAuth2::useDynamicBuffer()']]],
  ['useimportedbuffer_204',['useImportedBuffer',['../de/d6f/class_t_e_b___drive.html#aadce01002b056a4d47d770b330bb5e2f',1,'TEB_Drive::useImportedBuffer()'],['../d9/dca/class_t_e_b___o_auth2.html#aa8eb35ebd7520d5e9191bdc1bbd66cc6',1,'TEB_OAuth2::useImportedBuffer()']]]
];
