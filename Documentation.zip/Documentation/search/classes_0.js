var searchData=
[
  ['request_0',['request',['../dc/df6/struct_t_e_b___h_t_t_p_1_1request.html',1,'TEB_HTTP']]],
  ['response_1',['response',['../dc/d95/struct_t_e_b___h_t_t_p_1_1response.html',1,'TEB_HTTP']]]
];
