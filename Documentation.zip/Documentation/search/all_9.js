var searchData=
[
  ['newdevicefile_0',['newDeviceFile',['../d1/de3/class_t_e_b___drive___remote___control___interface.html#a3a8dd782d2d1f30f66aa0036ad0efad4',1,'TEB_Drive_Remote_Control_Interface']]]
];
