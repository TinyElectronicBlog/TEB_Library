var searchData=
[
  ['deallocate_14',['deallocate',['../df/d8d/class_t_e_b___abstract___array.html#abc33d5d1ed390d60d716a7c9b5c6e687',1,'TEB_Abstract_Array::deallocate()'],['../dd/df4/class_t_e_b___splittable___array.html#abe6f0420a8b17d5ae8ef4682fce3bf31',1,'TEB_Splittable_Array::deallocate()']]],
  ['deletefile_15',['deleteFile',['../de/d6f/class_t_e_b___drive.html#a82c95704e28a3c13448baf16f0b4b366',1,'TEB_Drive']]],
  ['deleterefreshtokeneeprom_16',['deleteRefreshTokenEEPROM',['../d9/dca/class_t_e_b___o_auth2.html#a7932eee7155581e05511cb9fef313b73',1,'TEB_OAuth2']]],
  ['disconnect_17',['disconnect',['../d9/da0/class_t_e_b___development_board_1_1_t_e_b___wi_fi.html#ae2dd58648ae6acb446936900171989ce',1,'TEB_DevelopmentBoard::TEB_WiFi']]],
  ['dx_18',['DX',['../dd/df4/class_t_e_b___splittable___array.html#a72aa9ae9515598b3498a2fc241bd3905',1,'TEB_Splittable_Array']]],
  ['dynamicallocation_19',['dynamicAllocation',['../df/d8d/class_t_e_b___abstract___array.html#a1398cb95939de9f19afe94d485460165',1,'TEB_Abstract_Array::dynamicAllocation(size_t sizeInBytes)'],['../df/d8d/class_t_e_b___abstract___array.html#a851721abef021cfdbd5073cd23285ee6',1,'TEB_Abstract_Array::dynamicAllocation(size_t numberOfElements, size_t sizeOf1ElementInBytes)']]]
];
