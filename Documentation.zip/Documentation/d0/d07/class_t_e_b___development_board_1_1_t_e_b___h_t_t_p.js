var class_t_e_b___development_board_1_1_t_e_b___h_t_t_p =
[
    [ "request", "db/d1f/struct_t_e_b___development_board_1_1_t_e_b___h_t_t_p_1_1request.html", "db/d1f/struct_t_e_b___development_board_1_1_t_e_b___h_t_t_p_1_1request" ],
    [ "response", "da/d7e/struct_t_e_b___development_board_1_1_t_e_b___h_t_t_p_1_1response.html", "da/d7e/struct_t_e_b___development_board_1_1_t_e_b___h_t_t_p_1_1response" ]
];